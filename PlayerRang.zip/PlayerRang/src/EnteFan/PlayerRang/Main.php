<?php

declare(strict_types=1);

namespace EnteFan\PlayerRang;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as c;
use pocketmine\level\Position;
use pocketmine\level\sound\AnvilBreakSound;
use pocketmine\level\sound\PopSound;
use pocketmine\math\Vector3;

class Main extends PluginBase implements Listener{
  
  public const PREFIX = "§0[§1PlayerRang§0] ";
  
  public $online;
  
  public function onEnable(){
    $this->getServer()->getPluginManager()->registerEvents($this, $this);
    $this->getLogger()->info(c::GREEN . "PlayerRang wurder aktiviert");
    @mkdir($this->getDataFolder() . "ränge");
  }
  
  public function onDisable(){
    $this->getLogger()->info(c::RED . "PlayerRang wurder deaktiviert");
  }
  
  public function onQuit(PlayerQuitEvent $event){
    $sender = $event->getPlayer();
    $config = new Config($this->getDataFolder() . "ränge/" . $sender->getName() . ".yml", Config::YAML);
    $config->save();
  }
  
  public function onJoin(PlayerJoinEvent $event){
    $sender = $event->getPlayer();
    $config = new Config($this->getDataFolder() . "ränge/" . $sender->getName() . ".yml", Config::YAML);
    if($sender->hasPlayedBefore() == false){
        $config->set("Rang", 0);
    }
    if($config->get("Rang") == 0){
        $sender->setDisplayName("§7[Normie] | ". $sender->getName() . "");
        $sender->setNameTag("§7[Normie] | ". $sender->getName() . "");
    }
    if($config->get("Rang") == 1){
        $sender->setDisplayName("§4Owner  | §c" . $sender->getName(). "");
        $sender->setNameTag("§4Owner  | §c" . $sender->getName(). "");
    }
    if($config->get("Rang") == 2){
        $sender->setDisplayName("§cMod | §c" . $sender->getName(). "");
        $sender->setNameTag("§cMod | §c" . $sender->getName(). "");
    }
    if($config->get("Rang") == 3){
        $sender->setDisplayName("§bSupporter | " . $sender->getName(). "");
        $sender->setNameTag("§b9Supporter | " . $sender->getName(). "");
    }
    if($config->get("Rang") == 4){
        $sender->setDisplayName("§4Admin | " . $sender->getName(). "");
        $sender->setNameTag("§4Admin | " . $sender->getName(). "");
    }
    if($config->get("Rang") == 5){
        $sender->setDisplayName("§bDeveloper | " . $sender->getName(). "");
        $sender->setNameTag("§bDeveloper | " . $sender->getName(). "");
    }
    if($config->get("Rang") == 6){
        $sender->setDisplayName("§3Content | " . $sender->getName(). "");
        $sender->setNameTag("§3Content | " . $sender->getName(). "");
    }
    if($config->get("Rang") == 7){
        $sender->setDisplayName("§eManagment | " . $sender->getName(). "");
        $sender->setNameTag("§eManagment | " . $sender->getName(). "");
    }
    if($config->get("Rang") == 8){
        $sender->setDisplayName("§1Designer | " . $sender->getName(). "");
        $sender->setNameTag("§1Designer | " . $sender->getName(). "");
    }
    if($config->get("Rang") == 9){
        $sender->setDisplayName("§2Builder | " . $sender->getName(). "");
        $sender->setNameTag("§2Builder | " . $sender->getName(). "");
    }
    if($config->get("Rang") == 10){
        $sender->setDisplayName("§6Premium | " . $sender->getName(). "");
        $sender->setNameTag("§6Premium | " . $sender->getName(). "");
    }
  }
  
  public function onChat(PlayerChatEvent $event){
    $sender = $event->getPlayer();
    $msg = $event->getMessage();
    $config = new Config($this->getDataFolder() . "ränge/" . $sender->getName() . ".yml", Config::YAML);
    if($config->get("Rang") == 1){
        $event->setFormat("§4Owner | " . $sender->getName() . " » §r" . $msg);
    }
    if($config->get("Rang") == 2){
        $event->setFormat("§cModerator | " . $sender->getName() . " » §r" . $msg);
    }
    if($config->get("Rang") == 3){
        $event->setFormat("§b9Supporter | " . $sender->getName() . " » §r" . $msg);
    }
    if($config->get("Rang") == 0){
        $event->setFormat("§7Normie | " . $sender->getName() . " » §r" . $msg);
    }
    if($config->get("Rang") == 4){
        $event->setFormat("§4Admin | " . $sender->getName() . " » §r" . $msg);      
    }
    if($config->get("Rang") == 5){
        $event->setFormat("§bDeveloper | " . $sender->getName() . "» §r" .$msg);
    }
    if($config->get("Rang") == 6){
        $event->setFormat("§3Content | " . $sender->getName() . " » §r" .$msg);
    }
    if($config->get("Rang") == 7){
        $event->setFormat("§eManagment | " . $sender->getName() . " » §r" .$msg);
    }
    if($config->get("Rang") == 8){
        $event->setFormat("§1Designer | " . $sender->getName() . " » §r" .$msg);
    }  
    if($config->get("Rang") == 9){
        $event->setFormat("§2Builder | " . $sender->getName() . " » §r" .$msg);
    }
    if($config->get("Rang") == 10){
        $event->setFormat("§6Premium | " . $sender->getName() . " » §r" .$msg);
    }
  }
  
  public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool{
    switch($cmd->getName()){
      case "rang":
        if($sender instanceof Player){
          $config = new Config($this->getDataFolder() . "ränge/" . $sender->getName() . ".yml", Config::YAML);
          if($sender->isOp() or $config->get("Rang") == 1){
              $this->AddRangWindow($sender);
          }
        } else {
              $sender->sendMessage(Main::PREFIX . " §cDas kannst du nur in-game machen");
        }
      break;
    }
    return true;
  }
  
  public function AddRangWindow($sender){
    $list = [];
    foreach($this->getServer()->getOnlinePlayers() as $p){
        $list[] = $p->getName();
    }
    
    $this->online[$sender->getName()] = $list;
    
    $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
    $form = $api->createCustomForm(function(Player $sender, array $data = null){
      if($data === null){
          return true;
      }
      $index = $data[1];
      $playerName = $this->online[$sender->getName()][$index];
      if(is_numeric($data[0])){
        $config = new Config($this->getDataFolder() . "ränge/" . $playerName . ".yml", Config::YAML);
        $config->set("Rang", $data[0]);
        $config->save();
        $sender->sendMessage(Main::PREFIX . " §aDu hast den Spieler §d" . $playerName . " §aeinen Rang Gegeben");
        $sender->getlevel()->addSound(new PopSound($sender));
      } else {
        $sender->sendMessage(Main::PREFIX . "§cDu musst eine Rang nummer Schreiben");
        $sender->getlevel()->addSound(new AnvilBreakSound($sender));
      }
    });
    $form->setTitle("Add Player Rang");
    $form->addInput("§eSchreibe eine Rang Nummer 1-3");
    $form->addDropdown("§aWähle einen Spieler aus", $this->online[$sender->getName()]);
    $form->addLabel("§41. Owner\n§c2. Moderator\n§93. Supporter\n§44. Admin\n§b5. Developer\n§36. Content\n§e7. Managment\n§18. Designer\n§29. Builder\n§610. Premium");
    $form->sendToPlayer($sender);
    return $form;
  }
}